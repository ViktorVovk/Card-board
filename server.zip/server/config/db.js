module.exports = {
  url: "mongodb://viktorvovk:losangeles123@ds145921.mlab.com:45921/textcard",
};
