var ObjectID = require('mongodb').ObjectID;
module.exports = function (app, db) {

  app.put('/data/:id', (req, res) => {
    const id = req.params.id;
    console.log(id)
    const details = {
      '_id': new ObjectID(id)
    };
    const note = {
        title: req.body.title,
        text: req.body.text,
        options: {
          parent: req.body.options.parent,
          parentId: req.body.options.parentId,
          top: req.body.options.top,
          left: req.body.options.left,
          color: req.body.options.color
        }
      }
    db.collection('datacollection').update(details, note, (err, result) => {
      if (err) {
        res.send({
          'error': 'An error has occurred'
        });
      } else {
        res.send(note);
      }
    });
  });

  app.get('/data', (req, res) => {
    db.collection('datacollection').find({}).toArray(function (err, result) {
      if (err) throw err;
      res.send(result);
    });
  });

  app.post('/data', (req, res) => {
    const note = {
      title: req.body.title,
      text: req.body.text,
      options: {
        parent: req.body.options.parent,
        parentId: req.body.options.parentId,
        top: req.body.options.top,
        left: req.body.options.left,
        color: req.body.options.color
      }

    };
    db.collection('datacollection').insert(note, (err, result) => {
      if (err) {
        res.send({
          'error': 'An error has occurred'
        });
      } else {
        res.send(result.ops[0]);
      }
    });
  });
};